# Frontend

Run:

```bash
npm install
npm run dev
```

Create `.env` from `.env.example`:

```env
VITE_API_URL=http://localhost:8000
```

Open http://localhost:5173.
